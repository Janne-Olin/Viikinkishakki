﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Viikinkishakki
{
    class Game
    {
        public List<Piece> AttPieces { get; set; } = new List<Piece>();
        public List<Piece> DefPieces { get; set; } = new List<Piece>();
        public Piece Selected { get; set; }

        public Game()
        {
            Selected = null;
            CreatePieces();
        }

        private void CreatePieces()
        {
            AttPieces.Add(new AttPiece(0, 3));
            AttPieces.Add(new AttPiece(0, 4));
            AttPieces.Add(new AttPiece(0, 5));
            AttPieces.Add(new AttPiece(0, 6));
            AttPieces.Add(new AttPiece(0, 7));
            AttPieces.Add(new AttPiece(1, 5));
            AttPieces.Add(new AttPiece(3, 0));
            AttPieces.Add(new AttPiece(3, 10));
            AttPieces.Add(new AttPiece(4, 0));
            AttPieces.Add(new AttPiece(4, 10));
            AttPieces.Add(new AttPiece(5, 0));
            AttPieces.Add(new AttPiece(5, 1));
            AttPieces.Add(new AttPiece(5, 9));
            AttPieces.Add(new AttPiece(5, 10));
            AttPieces.Add(new AttPiece(6, 0));
            AttPieces.Add(new AttPiece(6, 10));
            AttPieces.Add(new AttPiece(7, 0));
            AttPieces.Add(new AttPiece(7, 10));
            AttPieces.Add(new AttPiece(9, 5));
            AttPieces.Add(new AttPiece(10, 3));
            AttPieces.Add(new AttPiece(10, 4));
            AttPieces.Add(new AttPiece(10, 5));
            AttPieces.Add(new AttPiece(10, 6));
            AttPieces.Add(new AttPiece(10, 7));

            DefPieces.Add(new DefPiece(3, 5));
            DefPieces.Add(new DefPiece(4, 4));
            DefPieces.Add(new DefPiece(4, 5));
            DefPieces.Add(new DefPiece(4, 6));
            DefPieces.Add(new DefPiece(5, 3));
            DefPieces.Add(new DefPiece(5, 4));
            DefPieces.Add(new DefPiece(5, 5, true));
            DefPieces.Add(new DefPiece(5, 6));
            DefPieces.Add(new DefPiece(5, 7));
            DefPieces.Add(new DefPiece(6, 4));
            DefPieces.Add(new DefPiece(6, 5));
            DefPieces.Add(new DefPiece(6, 6));
            DefPieces.Add(new DefPiece(7, 5));

            AddToBoard();
        }

        private void AddToBoard()
        {
            foreach (Piece piece in AttPieces)
            {
                int x = piece.XPos;
                int y = piece.YPos;

                PBoxGrid.Grid[x, y].BackColor = Color.Brown;
            }

            foreach (DefPiece piece in DefPieces)
            {
                int x = piece.XPos;
                int y = piece.YPos;

                if (!piece.IsKing)
                {
                    PBoxGrid.Grid[x, y].BackColor = Color.DarkOrange;
                }
                else
                {
                    PBoxGrid.Grid[x, y].BackColor = Color.Gold;
                }
            }
        }

        public void BoardClicked(int x, int y)
        {
            if (Selected != null)
            {
                MakeMove(x, y);
                return;
            }

            foreach (Piece piece in AttPieces)
            {
                if (piece.XPos == x && piece.YPos == y)
                {
                    Selected = piece;
                    PBoxGrid.Grid[x, y].BackColor = Color.Red;
                    break;
                }
            }

            foreach (Piece piece in DefPieces)
            {
                if (piece.XPos == x && piece.YPos == y)
                {
                    Selected = piece;
                    PBoxGrid.Grid[x, y].BackColor = Color.Yellow;
                    break;
                }
            }
        }

        private void MakeMove(int x, int y)
        {
            if (MoveIsLegal(x, y))
            {
                PBoxGrid.Grid[Selected.XPos, Selected.YPos].BackColor = Control.DefaultBackColor;

                Selected.XPos = x;
                Selected.YPos = y;
                AddToBoard();
                CheckCaptures();
                Selected = null;
            }
        }

        private bool MoveIsLegal(int x, int y)
        {
            if (Selected.XPos != x && Selected.YPos != y)
            {
                return false;
            }
            
            if (Selected.XPos != x)
            {
                if (Selected.XPos > x)
                {
                    for (int i = Selected.XPos - 1; i >= x ; i--)
                    {
                        if (PBoxGrid.Grid[i, y].BackColor != Control.DefaultBackColor)
                        {
                            return false;
                        }
                    }
                }
                else if (Selected.XPos < x)
                {
                    for (int i = Selected.XPos + 1; i <= x; i++)
                    {
                        if (PBoxGrid.Grid[i, y].BackColor != Control.DefaultBackColor)
                        {
                            return false;
                        }
                    }
                }                    
            }

            else if (Selected.YPos != y)
            {
                if (Selected.YPos > y)
                {
                    for (int i = Selected.YPos - 1; i >= y; i--)
                    {
                        if (PBoxGrid.Grid[x, i].BackColor != Control.DefaultBackColor)
                        {
                            return false;
                        }
                    }
                }
                else if (Selected.YPos < y)
                {
                    for (int i = Selected.YPos + 1; i <= y; i++)
                    {
                        if (PBoxGrid.Grid[x, i].BackColor != Control.DefaultBackColor)
                        {
                            return false;
                        }
                    }
                }
            }

            return true;
        }

        private void CheckCaptures()
        {
            List<Piece> ToBeRemoved = new List<Piece>();

            if (Selected is AttPiece)
            {
                foreach (Piece piece in DefPieces)
                {
                    if ((Selected.XPos == piece.XPos) && (Selected.YPos + 1 == piece.YPos || Selected.YPos - 1 == piece.YPos))
                    {
                        foreach (Piece attPiece in AttPieces)
                        {
                            if (attPiece.Equals(Selected))
                            {
                                continue;
                            }

                            if (attPiece.XPos != Selected.XPos)
                            {
                                continue;
                            }

                            if (Selected.YPos > piece.YPos)
                            {
                                if (Selected.YPos - 2 == attPiece.YPos)
                                {
                                    ToBeRemoved.Add(piece);
                                }
                            }

                            else if (Selected.YPos < piece.YPos)
                            {
                                if (Selected.YPos + 2 == attPiece.YPos)
                                {
                                    ToBeRemoved.Add(piece);
                                }
                            }
                        }
                    }

                    else if ((Selected.YPos == piece.YPos) && (Selected.XPos + 1 == piece.XPos || Selected.XPos - 1 == piece.XPos))
                    {
                        foreach (Piece attPiece in AttPieces)
                        {
                            if (attPiece.Equals(Selected))
                            {
                                continue;
                            }

                            if (attPiece.YPos != Selected.YPos)
                            {
                                continue;
                            }

                            if (Selected.XPos > piece.XPos)
                            {
                                if (Selected.XPos - 2 == attPiece.XPos)
                                {
                                    ToBeRemoved.Add(piece);
                                }
                            }

                            else if (Selected.XPos < piece.XPos)
                            {
                                if (Selected.XPos + 2 == attPiece.XPos)
                                {
                                    ToBeRemoved.Add(piece);
                                }
                            }
                        }
                    }
                }               
            }

            if (ToBeRemoved.Count > 0)
            {
                RemoveCaptured(ToBeRemoved);
            }
        }

        private void RemoveCaptured(List<Piece> deleteThese)
        {
            foreach (Piece piece in deleteThese)
            {
                PBoxGrid.Grid[piece.XPos, piece.YPos].BackColor = Control.DefaultBackColor;

                if (piece is AttPiece)
                {
                    AttPieces.Remove(piece);
                }
                else if (piece is DefPiece)
                {
                    DefPieces.Remove(piece);
                }
            }


        }
    }
}
